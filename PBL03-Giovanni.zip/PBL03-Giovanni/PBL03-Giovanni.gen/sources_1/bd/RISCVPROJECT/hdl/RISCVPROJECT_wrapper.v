//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
//Date        : Wed Oct 14 15:47:10 2026
//Host        : DESKTOP-9ELRCFC running 64-bit major release  (build 9200)
//Command     : generate_target RISCVPROJECT_wrapper.bd
//Design      : RISCVPROJECT_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module RISCVPROJECT_wrapper
   (clk_0,
    dpad_in_0,
    led0_out_0,
    led1_out_0,
    led2_out_0,
    led3_out_0,
    reset_0,
    switches_in_0);
  input clk_0;
  input [3:0]dpad_in_0;
  output [31:0]led0_out_0;
  output [31:0]led1_out_0;
  output [31:0]led2_out_0;
  output [31:0]led3_out_0;
  input reset_0;
  input [31:0]switches_in_0;

  wire clk_0;
  wire [3:0]dpad_in_0;
  wire [31:0]led0_out_0;
  wire [31:0]led1_out_0;
  wire [31:0]led2_out_0;
  wire [31:0]led3_out_0;
  wire reset_0;
  wire [31:0]switches_in_0;

  RISCVPROJECT RISCVPROJECT_i
       (.clk_0(clk_0),
        .dpad_in_0(dpad_in_0),
        .led0_out_0(led0_out_0),
        .led1_out_0(led1_out_0),
        .led2_out_0(led2_out_0),
        .led3_out_0(led3_out_0),
        .reset_0(reset_0),
        .switches_in_0(switches_in_0));
endmodule
